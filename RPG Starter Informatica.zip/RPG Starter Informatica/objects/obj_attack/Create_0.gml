damage = 1;
