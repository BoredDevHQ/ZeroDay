// Check if there are any enemies left in the room
if (instance_number(obj_enemy_parent) <= 0) {
    room_goto_next();
} 