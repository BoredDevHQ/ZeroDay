if (alarm[0] < 0)
{
    hp -= other.damage;
    alarm[0] = 60;
    image_blend = c_red;
    
    if (hp <= 0)
    {
        // Create drooeath effect or animation if you want
        // Then restart the room after a short delay
        instance_destroy();
        room_restart();
    }
}

