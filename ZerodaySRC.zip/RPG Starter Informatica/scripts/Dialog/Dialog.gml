function create_dialog(_messages){
    if (instance_exists(obj_dialog)) return;
        
    var _inst = instance_create_depth(0, 0, 0, obj_dialog);
    _inst.messages = _messages;
    _inst.current_message = 0;
    
}

char_colors = {
    "Congrats": c_yellow,
    "Chris": c_aqua,
    "Ghost": c_orange,
    "Narrator": c_white,
    "Unknown": c_white,
    "Pear Store": c_yellow,
    "Pear Store Employee": c_aqua,
    "Starbucks": c_yellow,
    "Starbucks Employee": c_aqua,
    "The ByteCave": c_yellow,
    
}

pearstore = [
{
    name: "Pear Store",
    msg: "Entering The Pear Store"
},

]
cam_diag1 = [
{
    name: "Pear Store",
    msg: "Enter.."
},

]
welcome_dialog = [
{
    name: "Ghost",
    msg: "I'm Ghost, welcome to the city of dreams Chris! Atleast, that's what it was."
},
{
    name: "Chris",
    msg: "How so?"
},
{
    name: "Ghost",
    msg: "Pear Computers, the huge tech company took over the entire government and now everyone gets monitored 24/7, camera's are everywhere and people have had enough, including us. So we have to take action."
},
{
    name: "Chris",
    msg: "Take action, how? What can we do if they monitor us all?"
},
{
    name: "Ghost",
    msg: "We have to take action by attacking from inside out, breaking their servers and cause chaos in the company till it crumbles. Go have a look around in town, come back here when you have a nice laptop, and get me some coffee, will ya?"
    
},
]
pearstore = [
{
    name: "Pear Store",
    msg: "Entering the Pear Store"
},

]
enterstarbucks = [
{
    name: "Starbucks",
    msg: "Entering Starbucks"
},

]


pearstoreemployee = [
{
    name: "Pear Store Employee",
    msg: "Welcome to the pear store! Looking for a Pearbook Air or a Pearbook Pro?"
},
{
    name: "Chris",
    msg: "Pearbook Pro please."
},
{
    name: "Pear Store Employee",
    msg: "That will be 2 of your kidneys then!"
},
{
    name: "Chris",
    msg: "Excuse me?"
},
{
    name: "Pear Store Employee",
    msg: "Just kidding, €3,499 Please. "
},
{
    name: "Chris",
    msg: "Here ya go!"
},
{
    name: "Pear Store Employee",
    msg: "Thank you! Enjoy your new PearBook pro and make sure to give us all your personal data!"
},
{
    name: "Chris",
    msg: "Yeah yeah, sure.. Weirdo."
},
]

starbucksemployee = [
{
    name: "Starbucks Employee",
    msg: "Welcome to Starbucks! Our system doesn't seem to recognize you so i can't give you your daily coffee... Did you give your personal data to Pear yet?"
},
{
    name: "Chris",
    msg: "Damn, y'all have a system like that? And no i didn't, nor will i ever give my data to that shitty company."
},
{
    name: "Starbucks Employee",
    msg: "Don't say that stuff about Pear, they hear everything you know.. But.. Are you part of the uh.. Resistance?.."
},
{
    name: "Chris",
    msg: "Can't say, i won't admit to anything... Anyways can i have 2 cappuccino's with no sugar?"
},
{
    name: "Starbucks Employee",
    msg: "Yeah sure, coming right up!"
},
{
    name: "Chris",
    msg: "Great."
},
{
    name: "Starbucks Employee",
    msg: "And here you go! Don't forget to come back later if you need it for your.. legal computer needs.."
},
{
    name: "Chris",
    msg: "Will do!"
},

]
homeenter = [
{
    name: "The ByteCave",
    msg: "Entering The ByteCave"
},
]
d_endmission1 = [
{
    name: "Ghost",
    msg: "Look at that!!! Nice PearBook Pro, kind of weird to be buying products from the company we're taking down.. But we'll just root it and put Penguin on it."
},
{
    name: "Chris",
    msg: "Yeah.. True. Also here's your coffee, cappuccino. No sugar, no milk. "
},
{
    name: "Ghost",
    msg: "Thanks mate. I'll go set up that PearBook of yours. Give me a few minutes, aight?"
},
{
    name: "Congrats",
    msg: "Mission 1 'The Intro' finished."
},

]
d_startmission2 = [
{
    name: "Ghost",
    msg: "Well, i finished setting up your computer, but before you start doing actual jobs, we need to know you are capable of fighting."
},
{
    name: "Chris",
    msg: "I'm capable, for sure. "
},
{
    name: "Ghost",
    msg: "Alright, if you're so confident, how about we put it to the test? I'll let you fight some bots i stole from Pear, let's see if you survive it or not."
},
{
    name: "Chris",
    msg: "Great, trust me, those bots wont last long."
},

]
d_arena = [
{
    name: "Ghost",
    msg: "Welcome to the arena. Sorry for the blood.. and the bone pieces... Our last recruit wasn't so lucky.."
},
{
    name: "Chris",
    msg: "It's fine.. I'm a little nervous now though.."
},
{
    name: "Ghost",
    msg: "Well, you're gonna have to fight.. Or die. Like you can't just leave the resistance, you know where we are.. if you leave.. we'll have to kill you."
},
{
    name: "Chris",
    msg: "Great.. Let's just get over with it."
},
{
    name: "Ghost",
    msg: "Amazing. Use your 'SPACE' key to attack the bots, and please don't end up like the last guy.. It took hours to clean up those brain pieces."
},
]
d_arenad2 = [
{
    name: "Ghost",
    msg: "Holy shit. How did you- Nevermind. That was.. EPIC!!! Absolutely insane stuff dude."
},
{
    name: "Chris",
    msg: "With that 'holy shit' you meant you thought that i was going to die? That's messed up dude. I mean that last recruit man.. "
},
{
    name: "Ghost",
    msg: "Shut up... But yeah, i kinda did think you would die.."
},
{
    name: "Chris",
    msg: "Fuck, you."
},
{
    name: "Congrats",
    msg: "Mission 2 'Fuck, you.' finished."
},
]